"""Finite non-native namespace smoke; only fresh staging-owned paths are writable."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time,datetime,importlib.util
R=Path('@EXECUTION_08_ROOT@');C=R/'control'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
E=C/'candidate07-execution.json';assert sha(E)=='90bdbc8c0fe67f7af6600834a96d831c688ce02f3d158f3d892bdbd52efe1c3b'
e=json.loads(E.read_bytes());wrapper=C/'with_correctness_namespace_04.py'
assert sha(wrapper)=='aa678b5f49241f3eb327d364556637ce7998fba423770b588dbec609bee97472'
keys=('native_source','build','binaries','run','temporary')
assert all(not Path(e['paths'][k]).exists() and not Path(e['paths'][k]).is_symlink() for k in keys)
smoke=R/'staging/independent-wrapper-smoke-02';smoke.mkdir(parents=True,exist_ok=False)
changed=json.loads(E.read_bytes())
for k in keys:
 path=smoke/k;path.mkdir();changed['paths'][k]=str(path)
p=smoke/'execution.json';p.write_text(json.dumps(changed,indent=2)+'\n')
assert {k for k in e if e[k]!=changed[k]}=={'paths'}
assert {k for k in e['paths'] if e['paths'][k]!=changed['paths'][k]}==set(keys)
inside=r'''
from pathlib import Path
import ctypes,hashlib,json,os,sys,platform
import numpy,scipy,gtsam,importlib.util
c=json.loads(Path(sys.argv[1]).read_bytes());f=json.loads((Path(c['paths']['control'])/'candidate07-source-freeze.json').read_bytes())
source=Path(c['paths']['source'])
assert os.statvfs(source).f_flag & os.ST_RDONLY
files={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source.rglob('*')) if p.is_file()}
assert files==f['source']['files']
libraries={}
for name,item in c['runtime_artifacts'].items():
 if name.startswith('glibc239_'):
  actual=hashlib.sha256(Path(item['path']).read_bytes()).hexdigest();assert actual==item['sha256'];libraries[name]=actual
libc=ctypes.CDLL(None);libc.gnu_get_libc_version.restype=ctypes.c_char_p;version=libc.gnu_get_libc_version().decode();assert version=='2.39'
for key in ('native_source','build','binaries','run','temporary'):
 path=Path(c['paths'][key]);assert not (os.statvfs(path).f_flag & os.ST_RDONLY)
 (path/'namespace-writable-probe.txt').write_text('Only this staging path is intentionally writable.\n')
helper=Path('@EXECUTION_08_ROOT@/staging/independent-upstream-helper-02/verify_upstream_namespace_02.py')
reference=helper.with_name('upstream-pinned-tree-archive-reference.json')
assert hashlib.sha256(helper.read_bytes()).hexdigest()=='cbdcd6e19abee3ec3df8beb62147138ea6a9237a8cf0617b1c78140efbf1261c'
assert hashlib.sha256(reference.read_bytes()).hexdigest()=='3f5477e2482f108ff567ccde6e57d50bd050e7dc71eba5688e4839680cf61cdf'
spec=importlib.util.spec_from_file_location('upstream_check',helper);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
upstream=module.check(c['paths']['upstream_repository'],json.loads(reference.read_bytes()))
print(json.dumps({'upstream':upstream,'source_read_only':True,'source_files':len(files),'source_sha256':f['source']['sha256'],'glibc':version,'canonical_library_hashes':libraries,'scientific_imports':['numpy','scipy','gtsam'],'python':platform.python_version(),'numpy':numpy.__version__,'scipy':scipy.__version__,'writable_outputs':'five staging-only paths','pid_namespace':os.readlink('/proc/self/ns/pid')}))
'''
code=smoke/'inside.py';code.write_text(inside)
command=['/usr/bin/python3',str(wrapper),'--execution',str(p),'--execution-sha256',sha(p),'--',changed['paths']['python'],str(code),str(p)]
spec=importlib.util.spec_from_file_location('smoke07_driver',C/'validate_candidate_07.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
assert sha(C/'validate_candidate_07.py')=='739d39ab68361dcf9233ceb5e8abfd92f68256bca39b18482df17909ab577d71'
checked=m.load_required_pins(C/'candidate07-pins.json',E)
assert sha(C/'candidate07-pins.json')=='91b84d5a702c0b782f80cbebf68d2576c54797f809e9247eceaf4caeceee57d5'
verified=m.verify_pins(checked,e,E)
assert len(verified['files'])==771 and len(checked['input_artifacts'])==14
admission=m.admission(e)
logpath=smoke/'stdout.log';owned=None
try:
 with logpath.open('w') as log:
  owned=m.OwnedCommand(command,cwd=R,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),log=log)
  deadline=time.monotonic()+60
  while owned.child.poll() is None:
   owned.observe()
   if time.monotonic()>deadline:raise TimeoutError('Finite namespace smoke timed out')
   time.sleep(.05)
  status=owned.child.returncode
finally:
 cleanup=owned.cleanup(force=owned.child.poll() is None) if owned is not None else {'verified':False}
assert status==0,logpath.read_text()
result=json.loads(logpath.read_text())
assert all(not Path(e['paths'][k]).exists() and not Path(e['paths'][k]).is_symlink() for k in keys)
print(json.dumps({'schema':'orbit-poc-candidate08-independent-namespace-smoke-v1','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':True,'actual_execution':{'path':str(E),'sha256':sha(E)},'smoke_execution':{'path':str(p),'sha256':sha(p)},'wrapper':{'path':str(wrapper),'sha256':sha(wrapper)},'derivation':'Exactly five mutable paths remapped into fresh staging; all source/runtime/input aliases unchanged.','argv':command,'returncode':status,'result':result,'cleanup':cleanup,'admission':admission,'production_mutable_directories_absent':True,'scope':'Scientific-runtime imports, source read-only mount, library identity and complete self-contained pinned upstream Git tree. No native orbit executable, compiler or fit launched.'},indent=2))
