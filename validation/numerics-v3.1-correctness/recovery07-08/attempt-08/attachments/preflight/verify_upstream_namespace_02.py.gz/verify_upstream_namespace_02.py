"""Read-only proof that a self-contained pinned upstream tree is usable here."""
from pathlib import Path
import argparse,hashlib,io,json,os,subprocess,tarfile

def require(value,message):
    if not value:raise ValueError(message)

def check(repository, expected):
    repository=Path(repository)
    require(repository.is_dir() and not repository.is_symlink(),'Upstream repository is absent or is a symlink')
    require(not any(os.environ.get(k) for k in ['GIT_DIR','GIT_WORK_TREE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES']),
            'External Git repository or alternate-object environment is forbidden')
    def git(*args):
        result=subprocess.run(['git','--git-dir='+str(repository),*args],capture_output=True,timeout=90)
        if result.returncode:raise ValueError('Upstream Git command failed: '+repr(args)+' '+result.stderr.decode(errors='replace'))
        return result.stdout
    require(git('rev-parse','--is-bare-repository').strip()==b'true','Upstream must be a bare repository')
    alternate=repository/'objects/info/alternates'
    require(not alternate.exists() and not alternate.is_symlink(),'Upstream alternate object database is forbidden, including hidden prior roots')
    shallow_history=(repository/'shallow').exists()  # Ancestor history is irrelevant to the complete pinned build tree.
    config=git('config','--list').decode()
    require('extensions.partialclone=' not in config.lower() and not any(line.lower().endswith('.promisor=true') for line in config.splitlines()),
            'Partial/promisor upstream repository is unsupported')
    commit=git('rev-parse','--verify',expected['commit']+'^{commit}').decode().strip()
    require(commit==expected['commit'],'Upstream commit identity changed')
    tree=git('rev-parse','--verify',commit+'^{tree}').decode().strip()
    require(tree==expected['tree'],'Upstream tree identity changed')
    raw=git('archive','--format=tar',commit)
    require(len(raw)==expected['archive_bytes'] and hashlib.sha256(raw).hexdigest()==expected['archive_sha256'],
            'Complete upstream archive identity changed')
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:') as archive:
        members=archive.getmembers()
        require(all(not Path(x.name).is_absolute() and '..' not in Path(x.name).parts for x in members),'Unsafe upstream archive path')
        count=sum(x.isfile() for x in members)
    require(count==expected['regular_files'],'Upstream regular-file inventory changed')
    return {'passed':True,'repository':str(repository),'commit':commit,'tree':tree,'archive_sha256':hashlib.sha256(raw).hexdigest(),
            'archive_bytes':len(raw),'regular_files':count,'external_alternates':False,'shallow_history':shallow_history,
            'scope':'Read-only Git object verification in the actual execution namespace; no native build, fit or clone is performed.'}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--repository',type=Path,required=True)
    parser.add_argument('--expected',type=Path,required=True);parser.add_argument('--expected-sha256',required=True)
    args=parser.parse_args();raw=args.expected.read_bytes()
    require(hashlib.sha256(raw).hexdigest()==args.expected_sha256,'Upstream reference receipt changed')
    print(json.dumps(check(args.repository,json.loads(raw)),indent=2))
