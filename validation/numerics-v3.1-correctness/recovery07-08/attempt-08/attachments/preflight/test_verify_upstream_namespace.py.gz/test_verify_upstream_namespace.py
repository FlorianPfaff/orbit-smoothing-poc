from pathlib import Path
import hashlib,importlib.util,io,subprocess,tarfile
import pytest
S=Path(__file__).with_name('verify_upstream_namespace.py')
spec=importlib.util.spec_from_file_location('upstream_namespace',S);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

@pytest.fixture
def repository(tmp_path):
    work=tmp_path/'work';bare=tmp_path/'upstream.git'
    subprocess.run(['git','init',str(work)],check=True,capture_output=True)
    (work/'source').mkdir();(work/'source/one.cpp').write_text('int original;\n')
    subprocess.run(['git','-C',str(work),'add','.'],check=True,capture_output=True)
    subprocess.run(['git','-C',str(work),'-c','user.name=Fixture','-c','user.email=fixture@example.invalid','commit','-m','upstream fixture'],check=True,capture_output=True)
    subprocess.run(['git','clone','--bare','--no-hardlinks',str(work),str(bare)],check=True,capture_output=True)
    commit=subprocess.check_output(['git','-C',str(work),'rev-parse','HEAD'],text=True).strip()
    tree=subprocess.check_output(['git','-C',str(work),'rev-parse','HEAD^{tree}'],text=True).strip()
    raw=subprocess.check_output(['git','-C',str(work),'archive','--format=tar',commit])
    with tarfile.open(fileobj=io.BytesIO(raw)) as t:count=sum(x.isfile() for x in t)
    return bare,{'commit':commit,'tree':tree,'archive_sha256':hashlib.sha256(raw).hexdigest(),'archive_bytes':len(raw),'regular_files':count}

def test_complete_bare_upstream_passes(repository):
    repo,expected=repository;assert m.check(repo,expected)['passed']

def test_missing_upstream_is_rejected(tmp_path):
    with pytest.raises(ValueError,match='absent'):m.check(tmp_path/'missing',{})

def test_wrong_commit_is_rejected(repository):
    repo,expected=repository;expected['commit']='0'*40
    with pytest.raises(ValueError,match='Git command failed'):m.check(repo,expected)

def test_hidden_alternate_is_rejected(repository):
    repo,expected=repository;(repo/'objects/info/alternates').write_text('/hidden/prior-root/objects\n')
    with pytest.raises(ValueError,match='alternate object database'):m.check(repo,expected)

def test_wrong_tree_is_rejected(repository):
    repo,expected=repository;expected['tree']='0'*40
    with pytest.raises(ValueError,match='tree identity'):m.check(repo,expected)

def test_missing_blob_is_rejected_despite_valid_commit_and_tree(repository):
    repo,expected=repository
    blob=subprocess.check_output(['git','--git-dir='+str(repo),'rev-parse','HEAD:source/one.cpp'],text=True).strip()
    (repo/'objects'/blob[:2]/blob[2:]).unlink()
    with pytest.raises(ValueError,match='Git command failed'):m.check(repo,expected)

def test_external_object_environment_is_rejected(repository,monkeypatch):
    repo,expected=repository;monkeypatch.setenv('GIT_ALTERNATE_OBJECT_DIRECTORIES','/hidden/objects')
    with pytest.raises(ValueError,match='environment'):m.check(repo,expected)
